"use client";

import { motion } from "framer-motion";
import { ExternalLink, Code2 } from "lucide-react";
import Image from "next/image";

const PROJECTS = [
  {
    id: 1,
    title: "Project Alpha",
    description: "A comprehensive web application built with Next.js and Tailwind CSS. It aims to solve common productivity issues using a minimalistic approach.",
    tags: ["Next.js", "React", "Tailwind CSS"],
    github: "#",
    link: "#",
  },
  {
    id: 2,
    title: "Project Beta",
    description: "An experimental mobile-first design system. Focuses on fluid typography and dynamic theming to provide an optimal user experience across devices.",
    tags: ["Design System", "Framer Motion", "CSS"],
    github: "#",
    link: "#",
  },
  {
    id: 3,
    title: "Project Gamma",
    description: "A data visualization dashboard that aggregates various APIs to present information in an easily digestible format using interactive charts.",
    tags: ["Data Viz", "APIs", "TypeScript"],
    github: "#",
    link: "#",
  },
  {
    id: 4,
    title: "Project Delta",
    description: "A lightweight open-source library for handling complex state management in smaller React applications without the boilerplate of Redux.",
    tags: ["Open Source", "React", "State Management"],
    github: "#",
    link: "#",
  }
];

export default function Projects() {
  return (
    <div className="max-w-4xl mx-auto py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="mb-12"
      >
        <h1 className="text-4xl font-bold tracking-tight mb-4">Projects</h1>
        <p className="text-lg text-muted-foreground">
          A collection of things I&apos;ve built and am currently working on.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {PROJECTS.map((project, index) => (
          <motion.div
            key={project.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            className="group flex flex-col rounded-xl border border-muted bg-accent/10 overflow-hidden hover:border-muted-foreground/30 transition-colors"
          >
            <div className="aspect-video bg-muted relative w-full overflow-hidden flex items-center justify-center">
              {/* Placeholder for an image */}
              <div className="absolute inset-0 bg-gradient-to-br from-accent to-muted opacity-50" />
              <span className="text-muted-foreground font-medium relative z-10">Image Placeholder</span>
            </div>
            
            <div className="p-6 flex flex-col flex-1">
              <h3 className="text-xl font-semibold mb-2 group-hover:text-foreground transition-colors">
                {project.title}
              </h3>
              <p className="text-muted-foreground text-sm mb-6 flex-1">
                {project.description}
              </p>
              
              <div className="flex flex-wrap gap-2 mb-6">
                {project.tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-2.5 py-1 rounded-md bg-accent/50 text-xs font-medium text-muted-foreground"
                  >
                    {tag}
                  </span>
                ))}
              </div>
              
              <div className="flex items-center gap-4 mt-auto">
                <a
                  href={project.github}
                  className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Code2 className="w-4 h-4" />
                  Code
                </a>
                <a
                  href={project.link}
                  className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <ExternalLink className="w-4 h-4" />
                  Live Demo
                </a>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}