"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

export default function Home() {
  return (
    <div className="flex flex-col items-start justify-center min-h-[70vh] max-w-3xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-6">
          Hi, I&apos;m <span className="text-muted-foreground">Alex</span>.
          <br />
          A student & creative thinker.
        </h1>
        <p className="text-lg md:text-xl text-muted-foreground mb-8 leading-relaxed max-w-2xl">
          I am passionate about building beautiful, functional digital experiences. Welcome to my personal space where I share my journey, what I&apos;m learning, and the projects I&apos;m working on.
        </p>
      </motion.div>

      <motion.div
        className="flex flex-wrap gap-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <Link
          href="/projects"
          className="inline-flex items-center justify-center rounded-md bg-foreground text-background px-6 py-3 text-sm font-medium transition-transform hover:scale-105"
        >
          View Projects
          <ArrowRight className="ml-2 h-4 w-4" />
        </Link>
        <Link
          href="/about"
          className="inline-flex items-center justify-center rounded-md border border-muted bg-transparent px-6 py-3 text-sm font-medium hover:bg-muted transition-colors"
        >
          More about me
        </Link>
      </motion.div>
    </div>
  );
}