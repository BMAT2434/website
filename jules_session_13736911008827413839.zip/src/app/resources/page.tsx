"use client";

import { motion } from "framer-motion";
import { Download, FileText, Code2, Link as LinkIcon } from "lucide-react";

export default function Resources() {
  return (
    <div className="max-w-3xl mx-auto py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl font-bold tracking-tight mb-4">Resources</h1>
        <p className="text-lg text-muted-foreground mb-12">
          A collection of my resume, helpful code snippets, and interesting articles or research papers I&apos;ve found valuable.
        </p>

        {/* Resume Section */}
        <section className="mb-16">
          <div className="flex items-center gap-3 mb-6">
            <FileText className="w-6 h-6 text-foreground" />
            <h2 className="text-2xl font-semibold tracking-tight">Resume</h2>
          </div>
          <div className="p-6 rounded-lg border border-muted bg-accent/20 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-lg font-medium">Curriculum Vitae</h3>
              <p className="text-sm text-muted-foreground">Updated Fall 2023 • PDF Document</p>
            </div>
            <a
              href="#"
              className="inline-flex items-center justify-center rounded-md bg-foreground text-background px-4 py-2 text-sm font-medium transition-transform hover:scale-105"
            >
              <Download className="mr-2 h-4 w-4" />
              Download Resume
            </a>
          </div>
        </section>

        {/* Code Snippets Section */}
        <section className="mb-16">
          <div className="flex items-center gap-3 mb-6">
            <Code2 className="w-6 h-6 text-foreground" />
            <h2 className="text-2xl font-semibold tracking-tight">Code Snippets</h2>
          </div>
          <div className="space-y-6">
            <div className="rounded-lg border border-muted bg-accent/10 overflow-hidden">
              <div className="bg-muted px-4 py-2 border-b border-muted flex justify-between items-center">
                <span className="text-sm font-medium text-muted-foreground">useWindowSize.ts</span>
              </div>
              <pre className="p-4 overflow-x-auto text-sm text-muted-foreground bg-[#0d1117] dark:bg-black">
                <code className="text-gray-300">
{`import { useState, useEffect } from 'react';

export function useWindowSize() {
  const [windowSize, setWindowSize] = useState({
    width: undefined,
    height: undefined,
  });

  useEffect(() => {
    function handleResize() {
      setWindowSize({
        width: window.innerWidth,
        height: window.innerHeight,
      });
    }
    window.addEventListener("resize", handleResize);
    handleResize();
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return windowSize;
}`}
                </code>
              </pre>
            </div>
          </div>
        </section>

        {/* Articles & Papers Section */}
        <section>
          <div className="flex items-center gap-3 mb-6">
            <LinkIcon className="w-6 h-6 text-foreground" />
            <h2 className="text-2xl font-semibold tracking-tight">Articles & Research</h2>
          </div>
          <ul className="space-y-4">
            {[
              {
                title: "Understanding React Server Components",
                source: "Vercel Blog",
                link: "#",
              },
              {
                title: "The Future of Web Typography",
                source: "Smashing Magazine",
                link: "#",
              },
              {
                title: "A Study on Minimalist UI/UX Principles",
                source: "Research Journal of Human-Computer Interaction",
                link: "#",
              }
            ].map((item, index) => (
              <li key={index} className="group">
                <a href={item.link} className="flex flex-col sm:flex-row sm:items-baseline gap-1 sm:gap-3 p-4 rounded-lg border border-transparent hover:border-muted hover:bg-accent/10 transition-all">
                  <h3 className="text-base font-medium group-hover:text-foreground transition-colors">{item.title}</h3>
                  <span className="text-sm text-muted-foreground flex-shrink-0">— {item.source}</span>
                </a>
              </li>
            ))}
          </ul>
        </section>
      </motion.div>
    </div>
  );
}