"use client";

import { motion } from "framer-motion";
import { BookOpen, Coffee, GraduationCap, Heart } from "lucide-react";

export default function About() {
  return (
    <div className="max-w-3xl mx-auto py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl font-bold tracking-tight mb-8">About Me</h1>
        <p className="text-lg text-muted-foreground mb-12 leading-relaxed">
          I am a passionate student eager to learn and build things that live on the internet. My focus is on creating clean, accessible, and user-centric digital experiences. Below you can find more about my educational background and what drives me outside of academics.
        </p>

        <section className="mb-16">
          <div className="flex items-center gap-3 mb-6">
            <GraduationCap className="w-6 h-6 text-foreground" />
            <h2 className="text-2xl font-semibold tracking-tight">Education</h2>
          </div>
          <div className="space-y-8 pl-4 border-l-2 border-muted ml-3">
            <div className="relative">
              <div className="absolute -left-[23px] top-1.5 w-3 h-3 rounded-full bg-muted-foreground" />
              <h3 className="text-xl font-medium">University of Technology</h3>
              <p className="text-muted-foreground text-sm mb-2">B.S. in Computer Science • 2021 - Present</p>
              <p className="text-muted-foreground leading-relaxed">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
              </p>
            </div>
            <div className="relative">
              <div className="absolute -left-[23px] top-1.5 w-3 h-3 rounded-full bg-muted-foreground" />
              <h3 className="text-xl font-medium">High School of Sciences</h3>
              <p className="text-muted-foreground text-sm mb-2">Science & Mathematics • 2017 - 2021</p>
              <p className="text-muted-foreground leading-relaxed">
                Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
              </p>
            </div>
          </div>
        </section>

        <section>
          <div className="flex items-center gap-3 mb-6">
            <Heart className="w-6 h-6 text-foreground" />
            <h2 className="text-2xl font-semibold tracking-tight">Interests</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-6 rounded-lg border border-muted bg-accent/30 hover:bg-accent/50 transition-colors">
              <BookOpen className="w-8 h-8 mb-4 text-muted-foreground" />
              <h3 className="text-lg font-medium mb-2">Reading & Research</h3>
              <p className="text-sm text-muted-foreground">
                Exploring new concepts in computer science, cognitive psychology, and design principles. I love reading technical blogs and academic papers.
              </p>
            </div>
            <div className="p-6 rounded-lg border border-muted bg-accent/30 hover:bg-accent/50 transition-colors">
              <Coffee className="w-8 h-8 mb-4 text-muted-foreground" />
              <h3 className="text-lg font-medium mb-2">Coffee & Code</h3>
              <p className="text-sm text-muted-foreground">
                Experimenting with new web technologies and frameworks in my free time, always accompanied by a good cup of coffee.
              </p>
            </div>
          </div>
        </section>
      </motion.div>
    </div>
  );
}